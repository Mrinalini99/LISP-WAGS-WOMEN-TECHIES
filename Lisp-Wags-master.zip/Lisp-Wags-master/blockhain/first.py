:import qrcode
img = qrcode.make('1EHNa6Q4Jz2uvNExL497mE43ikXhwF6kZm')
